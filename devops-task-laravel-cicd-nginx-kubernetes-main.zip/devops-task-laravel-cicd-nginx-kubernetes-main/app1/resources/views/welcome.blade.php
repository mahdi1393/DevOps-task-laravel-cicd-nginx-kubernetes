<!DOCTYPE html>
<html>
    <head>
        <title>App 1</title>
   </head>
    <body>
        <p>Hello I am App 1</p>
    </body>
</html>
