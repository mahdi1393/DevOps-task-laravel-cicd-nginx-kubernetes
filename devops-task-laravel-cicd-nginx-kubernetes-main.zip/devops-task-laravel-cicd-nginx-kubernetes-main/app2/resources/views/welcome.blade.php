<!DOCTYPE html>
<html>
    <head>
        <title>App 2</title>
   </head>
    <body>
        <p>Hello I am App 2</p>
    </body>
</html>
